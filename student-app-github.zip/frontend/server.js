const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Forward /api/* calls to the Java backend
app.use('/api', async (req, res) => {
  try {
    const options = { method: req.method, headers: { 'Content-Type': 'application/json' } };
    if (!['GET', 'HEAD', 'DELETE'].includes(req.method)) {
      options.body = JSON.stringify(req.body);
    }
    const response = await fetch(BACKEND_URL + '/api' + req.url, options);
    const text = await response.text();
    res.status(response.status).type('application/json').send(text);
  } catch (err) {
    res.status(502).json({ error: 'Backend unavailable. Is the Java app running?' });
  }
});

app.listen(PORT, () => console.log(`Frontend running at http://localhost:${PORT}`));
