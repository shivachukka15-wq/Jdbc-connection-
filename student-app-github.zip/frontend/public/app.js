const API = '/api/students';
const rows = document.getElementById('rows');
const form = document.getElementById('student-form');
const errorEl = document.getElementById('error');
const saveBtn = document.getElementById('save-btn');
const cancelBtn = document.getElementById('cancel-btn');
const f = {
  id: document.getElementById('id'),
  name: document.getElementById('name'),
  email: document.getElementById('email'),
  course: document.getElementById('course'),
};

async function request(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) throw new Error('Request failed (' + res.status + ')');
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

function cell(text) {
  const td = document.createElement('td');
  td.textContent = text;
  return td;
}

function button(label, cls, onClick) {
  const b = document.createElement('button');
  b.textContent = label;
  b.className = 'btn ' + cls;
  b.addEventListener('click', onClick);
  return b;
}

async function load() {
  try {
    errorEl.textContent = '';
    const students = await request(API);
    rows.innerHTML = '';
    if (students.length === 0) {
      const tr = document.createElement('tr');
      const td = cell('No students yet.');
      td.colSpan = 5;
      tr.appendChild(td);
      rows.appendChild(tr);
      return;
    }
    students.forEach((s) => {
      const tr = document.createElement('tr');
      [s.id, s.name, s.email, s.course].forEach((v) => tr.appendChild(cell(v)));
      const actions = document.createElement('td');
      actions.appendChild(button('Edit', '', () => startEdit(s)));
      actions.appendChild(document.createTextNode(' '));
      actions.appendChild(button('Delete', 'danger', () => remove(s.id)));
      tr.appendChild(actions);
      rows.appendChild(tr);
    });
  } catch (e) {
    errorEl.textContent = e.message;
  }
}

function startEdit(s) {
  f.id.value = s.id;
  f.name.value = s.name;
  f.email.value = s.email;
  f.course.value = s.course;
  saveBtn.textContent = 'Update Student';
  cancelBtn.hidden = false;
}

function resetForm() {
  form.reset();
  f.id.value = '';
  saveBtn.textContent = 'Add Student';
  cancelBtn.hidden = true;
}

async function remove(id) {
  if (!confirm('Delete this student?')) return;
  try {
    await request(API + '/' + id, { method: 'DELETE' });
    load();
  } catch (e) {
    errorEl.textContent = e.message;
  }
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = JSON.stringify({ name: f.name.value, email: f.email.value, course: f.course.value });
  const editing = f.id.value !== '';
  try {
    await request(editing ? API + '/' + f.id.value : API, {
      method: editing ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
    });
    resetForm();
    load();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

cancelBtn.addEventListener('click', resetForm);
load();
